package com.example.lostandfound

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.pusher.pushnotifications.PushNotifications
import okhttp3.OkHttpClient
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val lastFoundTextView: TextView = findViewById<TextView>(R.id.txtLastFound)

        val sharedPref = getPreferences(Context.MODE_PRIVATE) ?: return
        var interestKey = sharedPref.getString("interestKey", "")

        if (interestKey != "") {
            PushNotifications.start(applicationContext, "aec108c9-b429-42b1-85a8-d902ab81e61e")
            PushNotifications.addDeviceInterest(interestKey)
            lastFoundTextView.visibility = View.VISIBLE
            GetTime(interestKey.toString())
        }
        else {
            val userIDLabelLayout: TextInputLayout = findViewById<TextInputLayout>(R.id.textInputLayout)
            val userIDLabelTextView: TextView = findViewById<TextView>(R.id.txtUserIDLabel)
            val userIDTextInput: TextInputEditText = findViewById<TextInputEditText>(R.id.txtUserID)
            val registerButton: Button = findViewById<Button>(R.id.btnRegister)
            userIDLabelLayout.visibility = View.VISIBLE
            userIDLabelTextView.visibility = View.VISIBLE
            userIDTextInput.visibility = View.VISIBLE
            registerButton.visibility = View.VISIBLE

            registerButton.setOnClickListener {
                if (userIDTextInput.text.toString() != "") {
                    val url = "http://192.168.0.230:3000/validuser"
                    val jsonobj = JSONObject()
                    jsonobj.put("UserID", userIDTextInput.text.toString())

                    val que = Volley.newRequestQueue(this)
                    val req = JsonObjectRequest(
                        Request.Method.POST,url,jsonobj,
                        Response.Listener {
                                response ->
                            if (response.has("data")) {
                                val data = response.getJSONObject("data")
                                // _iid = address because _id used by Mongo
                                val _iid = data.getString("_iid")
                                if (_iid == "") {
                                    return@Listener
                                }
                                interestKey = _iid
                                with(sharedPref.edit()) {
                                    putString("interestKey", interestKey)
                                    apply()
                                }
                                if (interestKey != "") {
                                    PushNotifications.start(
                                        applicationContext,
                                        "aec108c9-b429-42b1-85a8-d902ab81e61e"
                                    )
                                    PushNotifications.addDeviceInterest(interestKey)
                                    lastFoundTextView.visibility = View.VISIBLE

                                    userIDLabelLayout.visibility = View.INVISIBLE
                                    userIDLabelTextView.visibility = View.INVISIBLE
                                    userIDTextInput.visibility = View.INVISIBLE
                                    registerButton.visibility = View.INVISIBLE
                                    GetTime(interestKey.toString())
                                }
                            }
                        }, Response.ErrorListener {
                            return@ErrorListener
                        }
                    )
                    que.add(req)
                }
                else {
                    return@setOnClickListener
                }
            }
        }
    }
    fun GetTime(interestKey: String)
    {
        val lastFoundTextView: TextView = findViewById<TextView>(R.id.txtLastFound)

        println(interestKey)

        val url = "http://192.168.0.230:3000/lastfound"
        val jsonobj = JSONObject()
        jsonobj.put("Address", interestKey)

        val queLastFound = Volley.newRequestQueue(this)
        val req = JsonObjectRequest(
            Request.Method.POST,url,jsonobj,
            {
                    response ->
                if (response.has("data")) {
                    val data = response.getJSONObject("data")
                    val _lastfound = data.getString("_lastFound")
                    lastFoundTextView.text = "Your item last found at $_lastfound"
                }
            }, {
                    error: VolleyError -> lastFoundTextView.text = "Error $error.message"
            }
        )
        queLastFound.add(req)
    }
}



